package com.budget_tracker.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
